package trial.example.math_way;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebView;

public class page8 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page8);
        WebView webView = (WebView) findViewById(R.id.webView);
        webView.loadUrl("https://drive.google.com/drive/u/5/folders/1-GHnw32YYyb4g0IhKUTY-v59rEuilapy");
    }
}
