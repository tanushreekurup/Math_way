package trial.example.math_way;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebView;

public class page7 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page7);
        WebView webView = (WebView) findViewById(R.id.webView);
        webView.loadUrl("https://drive.google.com/drive/u/5/folders/1-PMF50_isKDtKcm5v8ldu-7op7SIZYyK");
    }
}
