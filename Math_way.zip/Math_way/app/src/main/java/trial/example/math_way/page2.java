package trial.example.math_way;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class page2 extends AppCompatActivity {

    private Button b2;
    private Button b3;
    private Button b4;
    private Button b5;
    private Button b6;
    private Button b7;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page2);


        Button b2=findViewById(R.id.btn_2);
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openpage3();


            }
        });


        Button b3=findViewById(R.id.btn_3);
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openpage4();


            }
        });


        Button b4=findViewById(R.id.btn_4);
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openpage5();


            }
        });


        Button b5=findViewById(R.id.btn_5);
        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openpage6();


            }
        });


        Button b6=findViewById(R.id.btn_6);
        b6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openpage7();


            }
        });


        Button b7=findViewById(R.id.btn_7);
        b7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openpage8();


            }
        });


    }

    public void openpage3(){
        Intent intent=new Intent(this,page3.class);
        startActivity(intent);

    }

    public void openpage4(){
        Intent intent=new Intent(this,page4.class);
        startActivity(intent);

    }

    public void openpage5(){
        Intent intent=new Intent(this,page5.class);
        startActivity(intent);

    }

    public void openpage6(){
        Intent intent=new Intent(this,page6.class);
        startActivity(intent);

    }

    public void openpage7(){
        Intent intent=new Intent(this,page7.class);
        startActivity(intent);

    }

    public void openpage8(){
        Intent intent=new Intent(this,page8.class);
        startActivity(intent);

    }
}

