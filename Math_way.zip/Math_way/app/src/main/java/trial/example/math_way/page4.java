package trial.example.math_way;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebView;

public class page4 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page4);
        WebView webView = (WebView) findViewById(R.id.webView);
        webView.loadUrl("https://drive.google.com/drive/u/5/folders/1-3mL3wZfQ6w6jXEse-XKlLEzHs_fp2H0");
    }
}
